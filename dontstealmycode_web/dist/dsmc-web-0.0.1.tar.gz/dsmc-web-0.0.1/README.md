# dsmc-web

dsmc (DontStealMyCode-Web) is a python-based complete "framework" to encrypt and decrypt code or whatever file you want. Please the global repository for further details on how to use this on your websites.